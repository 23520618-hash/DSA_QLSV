from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from btree_index import BTree


@dataclass
class Student:
    student_id: str
    full_name: str
    gender: str
    note: str = ""


class StudentStore:
    def __init__(self) -> None:
        self.students: Dict[str, Student] = {}
        self.id_index = BTree(order=3)
        self.name_index = BTree(order=3)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return " ".join(name.lower().split())

    def add_student(self, student: Student) -> None:
        if student.student_id in self.students:
            raise ValueError(f"Student ID {student.student_id} already exists.")

        self.students[student.student_id] = student
        self.id_index.insert(student.student_id, student.student_id)

        normalized = self._normalize_name(student.full_name)
        existing = self.name_index.search(normalized)
        if existing is None:
            self.name_index.insert(normalized, [student.student_id])
        else:
            existing.append(student.student_id)

    def delete_student(self, student_id: str) -> bool:
        student = self.students.pop(student_id, None)
        if student is None:
            return False

        # Simpler and robust for a small educational demo: rebuild indexes.
        self._rebuild_indexes()
        return True

    def find_by_id(self, student_id: str) -> Optional[Student]:
        indexed_id = self.id_index.search(student_id)
        if indexed_id is None:
            return None
        return self.students.get(indexed_id)

    def find_by_name(self, full_name: str) -> List[Student]:
        normalized = self._normalize_name(full_name)
        ids = self.name_index.search(normalized) or []
        return [self.students[sid] for sid in ids if sid in self.students]

    def all_students(self) -> List[Student]:
        return sorted(self.students.values(), key=lambda s: s.student_id)

    def _rebuild_indexes(self) -> None:
        self.id_index = BTree(order=3)
        self.name_index = BTree(order=3)

        for sid, student in sorted(self.students.items()):
            self.id_index.insert(sid, sid)
            normalized = self._normalize_name(student.full_name)
            existing = self.name_index.search(normalized)
            if existing is None:
                self.name_index.insert(normalized, [sid])
            else:
                existing.append(sid)

    def dump_id_index(self) -> str:
        return self.id_index.visualize()

    def dump_name_index(self) -> str:
        return self.name_index.visualize()
