# Student Management with B-Tree (Order 3)

## Overview
This is a console application for student management.
Each student has:
- Student ID
- Full Name
- Gender
- Note

Supported operations:
- Add student
- Delete student
- Search by Student ID
- Search by Full Name

The app uses **B-Tree order 3** as indexes to speed up search:
- Index 1: by Student ID
- Index 2: by normalized Full Name

After each add/delete operation, the app prints:
- Base student table
- B-Tree index structure

## Run
Requirements: Python 3.10+

```bash
python app.py
```

## Demo Notes
- Initial data has 3 students.
- Search by name is case-insensitive and ignores extra spaces.
- For educational simplicity, delete operation rebuilds indexes after removing a row.
