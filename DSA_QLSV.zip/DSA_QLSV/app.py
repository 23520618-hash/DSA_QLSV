from __future__ import annotations

from student_store import Student, StudentStore


def print_students_table(store: StudentStore) -> None:
    rows = store.all_students()
    print("\n=== BANG DU LIEU GOC (STUDENT TABLE) ===")
    if not rows:
        print("(empty)")
        return

    header = f"{'Ma SV':<12} | {'Ho va Ten':<25} | {'Gioi tinh':<10} | Ghi chu"
    print(header)
    print("-" * len(header))
    for s in rows:
        print(f"{s.student_id:<12} | {s.full_name:<25} | {s.gender:<10} | {s.note}")


def print_indexes(store: StudentStore) -> None:
    print("\n=== CHI MUC B-TREE BAC 3 THEO MA SV ===")
    print(store.dump_id_index())

    print("\n=== CHI MUC B-TREE BAC 3 THEO HO TEN (normalize lower-case) ===")
    print(store.dump_name_index())


def print_state(store: StudentStore) -> None:
    print_students_table(store)
    print_indexes(store)


def seed_data(store: StudentStore) -> None:
    store.add_student(Student("SV001", "Nguyen Van An", "Nam", "CNTT"))
    store.add_student(Student("SV002", "Tran Thi Binh", "Nu", "KTPM"))
    store.add_student(Student("SV003", "Le Hoang Nam", "Nam", "ATTT"))


def menu() -> None:
    store = StudentStore()
    seed_data(store)

    while True:
        print("\n==============================")
        print("QUAN LY SINH VIEN - B-TREE INDEX")
        print("1. Hien thi toan bo du lieu + index")
        print("2. Them sinh vien")
        print("3. Xoa sinh vien theo Ma SV")
        print("4. Tim theo Ma SV")
        print("5. Tim theo Ho va Ten")
        print("0. Thoat")

        choice = input("Chon chuc nang: ").strip()

        if choice == "1":
            print_state(store)

        elif choice == "2":
            sid = input("Ma SV: ").strip()
            name = input("Ho va Ten: ").strip()
            gender = input("Gioi tinh: ").strip()
            note = input("Ghi chu: ").strip()
            try:
                store.add_student(Student(sid, name, gender, note))
                print("\nThem thanh cong. Trang thai moi:")
                print_state(store)
            except ValueError as exc:
                print(f"Loi: {exc}")

        elif choice == "3":
            sid = input("Nhap Ma SV can xoa: ").strip()
            if store.delete_student(sid):
                print("\nXoa thanh cong. Trang thai moi:")
                print_state(store)
            else:
                print("Khong tim thay sinh vien.")

        elif choice == "4":
            sid = input("Nhap Ma SV can tim: ").strip()
            student = store.find_by_id(sid)
            if student is None:
                print("Khong tim thay.")
            else:
                print("Tim thay (tra ve tu index Ma SV):")
                print(f"- {student.student_id} | {student.full_name} | {student.gender} | {student.note}")

        elif choice == "5":
            name = input("Nhap Ho va Ten can tim: ").strip()
            students = store.find_by_name(name)
            if not students:
                print("Khong tim thay.")
            else:
                print("Tim thay (tra ve tu index Ho ten):")
                for student in students:
                    print(
                        f"- {student.student_id} | {student.full_name} | {student.gender} | {student.note}"
                    )

        elif choice == "0":
            print("Tam biet.")
            break

        else:
            print("Lua chon khong hop le.")


if __name__ == "__main__":
    menu()
