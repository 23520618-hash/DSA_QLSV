from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class BTreeNode:
    leaf: bool = True
    keys: List[str] = field(default_factory=list)
    values: List[Any] = field(default_factory=list)
    children: List["BTreeNode"] = field(default_factory=list)


class BTree:
    """
    B-Tree of order 3 (max children = 3, max keys = 2).
    This implementation is tuned for educational visualization.
    """

    def __init__(self, order: int = 3) -> None:
        if order != 3:
            raise ValueError("This demo only supports order-3 B-Tree.")
        self.order = order
        self.max_keys = order - 1
        self.root = BTreeNode()

    def search(self, key: str) -> Optional[Any]:
        return self._search(self.root, key)

    def _search(self, node: BTreeNode, key: str) -> Optional[Any]:
        i = 0
        while i < len(node.keys) and key > node.keys[i]:
            i += 1
        if i < len(node.keys) and key == node.keys[i]:
            return node.values[i]
        if node.leaf:
            return None
        return self._search(node.children[i], key)

    def insert(self, key: str, value: Any) -> None:
        existing = self.search(key)
        if existing is not None:
            if isinstance(existing, list):
                existing.append(value)
            else:
                raise ValueError("Duplicate key detected on unique index.")
            return
        promoted = self._insert_recursive(self.root, key, value)
        if promoted is not None:
            mid_key, mid_val, right_node = promoted
            old_root = self.root
            self.root = BTreeNode(
                leaf=False,
                keys=[mid_key],
                values=[mid_val],
                children=[old_root, right_node],
            )

    def _insert_recursive(
        self, node: BTreeNode, key: str, value: Any
    ) -> Optional[tuple[str, Any, BTreeNode]]:
        if node.leaf:
            idx = 0
            while idx < len(node.keys) and node.keys[idx] < key:
                idx += 1
            node.keys.insert(idx, key)
            node.values.insert(idx, value)
        else:
            idx = 0
            while idx < len(node.keys) and key > node.keys[idx]:
                idx += 1
            promoted = self._insert_recursive(node.children[idx], key, value)
            if promoted is not None:
                mid_key, mid_val, right_node = promoted
                node.keys.insert(idx, mid_key)
                node.values.insert(idx, mid_val)
                node.children.insert(idx + 1, right_node)

        if len(node.keys) <= self.max_keys:
            return None

        mid_idx = len(node.keys) // 2
        mid_key = node.keys[mid_idx]
        mid_val = node.values[mid_idx]

        right_node = BTreeNode(
            leaf=node.leaf,
            keys=node.keys[mid_idx + 1 :],
            values=node.values[mid_idx + 1 :],
            children=node.children[mid_idx + 1 :] if not node.leaf else [],
        )

        node.keys = node.keys[:mid_idx]
        node.values = node.values[:mid_idx]
        if not node.leaf:
            node.children = node.children[: mid_idx + 1]

        return mid_key, mid_val, right_node

    def traverse(self) -> List[tuple[str, Any]]:
        output: List[tuple[str, Any]] = []
        self._traverse(self.root, output)
        return output

    def _traverse(self, node: BTreeNode, output: List[tuple[str, Any]]) -> None:
        for i, key in enumerate(node.keys):
            if not node.leaf:
                self._traverse(node.children[i], output)
            output.append((key, node.values[i]))
        if not node.leaf:
            self._traverse(node.children[-1], output)

    def visualize(self) -> str:
        lines: List[str] = []
        self._visualize(self.root, depth=0, lines=lines)
        return "\n".join(lines) if lines else "(empty)"

    def _visualize(self, node: BTreeNode, depth: int, lines: List[str]) -> None:
        indent = "  " * depth
        keys = " | ".join(node.keys) if node.keys else "-"
        lines.append(f"{indent}[{keys}]")
        for child in node.children:
            self._visualize(child, depth + 1, lines)
